package com.example.talkingclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import java.util.Calendar

class TimeService : Service() {
    private var last = 0L
    private var player: MediaPlayer? = null
    private val queue = mutableListOf<Int>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val now = SystemClock.elapsedRealtime()
            if (last != 0L && now - last < 1800) {
                last = 0L
                speakTime()
            } else {
                last = now
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val n: Notification = if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("clock", "Talking clock", NotificationManager.IMPORTANCE_LOW))
            Notification.Builder(this, "clock")
                .setContentTitle("ناطق الساعة شغال")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("ناطق الساعة شغال")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build()
        }
        startForeground(1, n)
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_SCREEN_OFF)
        registerReceiver(receiver, f)
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == "SPEAK") speakTime()
        return START_STICKY
    }

    private fun res(name: String): Int = resources.getIdentifier(name, "raw", packageName)

    private fun speakTime() {
        if (player != null || queue.isNotEmpty()) return
        val c = Calendar.getInstance()
        val h24 = c.get(Calendar.HOUR_OF_DAY)
        var h = h24 % 12
        if (h == 0) h = 12
        val m = c.get(Calendar.MINUTE)
        val period = when {
            h24 in 4..11 -> "p_morning"
            h24 in 12..17 -> "p_afternoon"
            else -> "p_night"
        }
        val names = mutableListOf("intro", "h_$h")
        if (m > 0) names.add("m_$m")
        names.add(period)
        for (n in names) {
            val id = res(n)
            if (id != 0) queue.add(id)
        }
        playNext()
    }

    private fun playNext() {
        if (queue.isEmpty()) { player = null; return }
        val id = queue.removeAt(0)
        val mp = MediaPlayer.create(this, id)
        if (mp == null) { playNext(); return }
        player = mp
        mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
        mp.setOnCompletionListener { it.release(); player = null; playNext() }
        mp.setOnErrorListener { m, _, _ -> m.release(); player = null; playNext(); true }
        mp.start()
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        unregisterReceiver(receiver)
        player?.release()
        super.onDestroy()
    }
}
