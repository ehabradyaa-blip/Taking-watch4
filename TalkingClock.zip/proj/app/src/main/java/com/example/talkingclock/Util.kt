package com.example.talkingclock

import android.content.Context
import android.content.Intent
import android.os.Build

fun startTimeService(ctx: Context, speak: Boolean) {
    val i = Intent(ctx, TimeService::class.java)
    if (speak) i.action = "SPEAK"
    if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
}
